package com.zybooks.weighttrackingapp_lanemelzark;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class WeightEntryActivity extends AppCompatActivity {
    private static final String TAG = "WeightEntryActivity";
    private EditText weightEditText;
    private Button addWeightButton, updateWeightButton, deleteWeightButton, goalWeightButton;
    private GridView weightGridView;
    private DatabaseHelper dbHelper;
    private ArrayList<String> weightsList;
    private ArrayAdapter<String> weightsAdapter;
    private String selectedWeight;

    private static final int SMS_PERMISSION_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_entry);

        // Initialize UI elements
        weightEditText = findViewById(R.id.weightEditText);
        addWeightButton = findViewById(R.id.addWeightButton);
        updateWeightButton = findViewById(R.id.updateWeightButton);
        deleteWeightButton = findViewById(R.id.deleteWeightButton);
        goalWeightButton = findViewById(R.id.goalWeightButton); // Ensure proper initialization
        weightGridView = findViewById(R.id.weightGridView);
        dbHelper = new DatabaseHelper(this);
        weightsList = new ArrayList<>();

        // Set up button click listeners
        addWeightButton.setOnClickListener(v -> {
            String weight = weightEditText.getText().toString();
            if (!weight.isEmpty()) {
                dbHelper.addWeight(weight);
                weightsList.add(weight);
                weightsAdapter.notifyDataSetChanged();
                weightEditText.setText("");
            } else {
                Toast.makeText(WeightEntryActivity.this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            }
        });

        updateWeightButton.setOnClickListener(v -> {
            String newWeight = weightEditText.getText().toString();
            if (!newWeight.isEmpty() && selectedWeight != null) {
                dbHelper.updateWeight(selectedWeight, newWeight);
                weightsList.set(weightsList.indexOf(selectedWeight), newWeight);
                weightsAdapter.notifyDataSetChanged();
                weightEditText.setText("");
                selectedWeight = null;
            } else {
                Toast.makeText(WeightEntryActivity.this, "Please select a weight to update", Toast.LENGTH_SHORT).show();
            }
        });

        deleteWeightButton.setOnClickListener(v -> {
            if (selectedWeight != null) {
                dbHelper.deleteWeight(selectedWeight);
                weightsList.remove(selectedWeight);
                weightsAdapter.notifyDataSetChanged();
                weightEditText.setText("");
                selectedWeight = null;
            } else {
                Toast.makeText(WeightEntryActivity.this, "Please select a weight to delete", Toast.LENGTH_SHORT).show();
            }
        });

        weightGridView.setOnItemClickListener((parent, view, position, id) -> {
            selectedWeight = weightsList.get(position);
            weightEditText.setText(selectedWeight);
            checkAndSendGoalWeightNotification();
        });

        goalWeightButton.setOnClickListener(v -> {
            Intent intent = new Intent(WeightEntryActivity.this, GoalWeightActivity.class);
            startActivity(intent);
        });

        loadWeights();
        requestSmsPermission();
    }

    private void loadWeights() {
        weightsList = dbHelper.getAllWeights();
        weightsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, weightsList);
        weightGridView.setAdapter(weightsAdapter);
    }

    private void requestSmsPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
            // Show an explanation to the user
            Toast.makeText(this, "SMS permission is required to send notifications when you reach your goal weight.", Toast.LENGTH_LONG).show();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // SMS permission granted
                Toast.makeText(this, "SMS permission granted!", Toast.LENGTH_SHORT).show();
            } else {
                // SMS permission denied
                Toast.makeText(this, "SMS permission denied. You will not receive notifications.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendSmsNotification(String phoneNumber, String message) {
        try {
            SmsManager smsManager;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                smsManager = this.getSystemService(SmsManager.class);
            } else {
                smsManager = SmsManager.getDefault(); // For lower API levels
            }
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS sent successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e(TAG, "SMS failed to send", e); // Replace printStackTrace with Log
            Toast.makeText(this, "SMS failed to send", Toast.LENGTH_SHORT).show();
        }
    }

    private void checkAndSendGoalWeightNotification() {
        String currentWeight = weightEditText.getText().toString();
        String goalWeight = dbHelper.getGoalWeight();

        if (!currentWeight.isEmpty() && goalWeight != null) {
            double currentWeightValue = Double.parseDouble(currentWeight);
            double goalWeightValue = Double.parseDouble(goalWeight);

            if (currentWeightValue <= goalWeightValue) {
                String phoneNumber = "1234567890"; // Replace with the actual phone number or retrieve from user input
                String message = "Congratulations! You've reached your goal weight of " + goalWeight + "!";
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    // Permission granted, send SMS
                    sendSmsNotification(phoneNumber, message);
                } else {
                    // Permission denied, show alternative notification (e.g., Toast message)
                    Toast.makeText(this, "Goal weight reached: " + goalWeight + "!", Toast.LENGTH_LONG).show();
                }
            }
        }
    }}