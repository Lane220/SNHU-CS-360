package com.zybooks.weighttrackingapp_lanemelzark;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class GoalWeightActivity extends AppCompatActivity {
    private EditText goalWeightEditText;
    private Button saveGoalButton;
    private TextView currentGoalWeightTextView;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_weight);

        goalWeightEditText = findViewById(R.id.goalWeightEditText);
        saveGoalButton = findViewById(R.id.saveGoalButton);
        currentGoalWeightTextView = findViewById(R.id.currentGoalWeightTextView);
        dbHelper = new DatabaseHelper(this);

        saveGoalButton.setOnClickListener(v -> {
            String goalWeight = goalWeightEditText.getText().toString();
            if (!goalWeight.isEmpty()) {
                dbHelper.setGoalWeight(goalWeight);
                currentGoalWeightTextView.setText(getString(R.string.current_goal_weight, goalWeight));
                goalWeightEditText.setText("");
            } else {
                Toast.makeText(GoalWeightActivity.this, "Please enter a goal weight", Toast.LENGTH_SHORT).show();
            }
        });

        loadGoalWeight();
    }

    private void loadGoalWeight() {
        String goalWeight = dbHelper.getGoalWeight();
        if (goalWeight != null) {
            currentGoalWeightTextView.setText(getString(R.string.current_goal_weight, goalWeight));
        }
    }
}